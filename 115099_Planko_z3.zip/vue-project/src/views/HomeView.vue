<script setup>
import PlayArea from '../components/PlayArea.vue'
</script>

<template>
  <PlayArea></PlayArea>
</template>
