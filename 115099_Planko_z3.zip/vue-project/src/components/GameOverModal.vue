<script setup></script>

<template>
  <div
    class="fixed top-0 left-0 z-10 min-w-full min-h-full bg-black bg-opacity-50 flex items-center justify-center"
  >
    <h1 class="text-white text-4xl text-center">GAME OVER</h1>
  </div>
</template>
